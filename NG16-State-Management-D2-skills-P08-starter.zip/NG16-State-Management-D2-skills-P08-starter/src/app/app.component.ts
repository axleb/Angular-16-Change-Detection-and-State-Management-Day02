import { Component, inject } from '@angular/core';
import { ProfileService } from "./profile.service";
//
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
//
export class AppComponent {
  title = 'profile';
  //userLoggedIn : boolean = false;
  userLoggedIn = inject(ProfileService);
  //
  logout(){
    this.userLoggedIn.logout();
   }
}
