import { Injectable, signal } from '@angular/core';
import { BehaviorSubject } from "rxjs";
//
@Injectable({
  providedIn: 'root'
})
//
export class ProfileService {
  //isLoggedIn = new BehaviorSubject<boolean>(false);
  isLoggedIn = signal<boolean>(false); 
  constructor() { }
  login(){
    //this.isLoggedIn.next(true);
    this.isLoggedIn.update( prevValue => true );
  }
  logout(){
    this.isLoggedIn.update( prevValue => false );
  }
}
